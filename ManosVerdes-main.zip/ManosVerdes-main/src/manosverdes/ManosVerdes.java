    package manosverdes;
public class ManosVerdes {
    
    
    public static void main(String[] args) 
    {
        FrameGuiaApp Ref = new FrameGuiaApp();
        Ref.setLocationRelativeTo(Ref);
        Ref.setVisible(true);
      
    }
    
}
