package manosverdes;
import Entidades.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;

public class FramePuntosDeReciclaje extends javax.swing.JFrame {

    FrameGuiaApp padre;
    //Creamos la lista y el modelo de lista para los puntos de recicalje
    List<PuntoReciclaje> puntos = new ArrayList<>(); 
    DefaultListModel<String>  mode = new DefaultListModel<>();
    //Creamos la lista y modelo de lista para los tipos de material
    List<Material> tipo = new ArrayList<>(); 
    DefaultListModel<Material>  mate = new DefaultListModel<>();


    public FramePuntosDeReciclaje()
    {   initComponents();
        agregar();
    }
    
    public FramePuntosDeReciclaje(FrameGuiaApp padre)
    {   initComponents();
        this.padre = padre;
        agregar();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_Fav = new javax.swing.JButton();
        btn_VerList = new javax.swing.JButton();
        Volver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_Fav.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesP/Group 169.png"))); // NOI18N
        btn_Fav.setBorder(null);
        btn_Fav.setContentAreaFilled(false);
        btn_Fav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_FavActionPerformed(evt);
            }
        });
        jPanel1.add(btn_Fav, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 310, 190, 260));

        btn_VerList.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesP/ad.png"))); // NOI18N
        btn_VerList.setBorder(null);
        btn_VerList.setContentAreaFilled(false);
        btn_VerList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_VerListActionPerformed(evt);
            }
        });
        jPanel1.add(btn_VerList, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 420, 260, 100));

        Volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesD/v1.png"))); // NOI18N
        Volver.setBorder(null);
        Volver.setContentAreaFilled(false);
        Volver.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesD/v2.png"))); // NOI18N
        Volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VolverActionPerformed(evt);
            }
        });
        jPanel1.add(Volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 610, 150, 70));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesP/FramePuntosdeReciclaje.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_FavActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_FavActionPerformed
       
        
        
    }//GEN-LAST:event_btn_FavActionPerformed

    private void btn_VerListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_VerListActionPerformed
      FrameListaPuntosDeReciclaje pantalla = new FrameListaPuntosDeReciclaje(this,puntos);
      pantalla.setLocationRelativeTo(pantalla);
      pantalla.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_btn_VerListActionPerformed

    private void VolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VolverActionPerformed
        this.padre.setLocationRelativeTo(this.padre);
        this.padre.setVisible(true);
        this.setVisible(false);  
    }//GEN-LAST:event_VolverActionPerformed


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public void agregar()
    {
        PuntoReciclaje ref = new PuntoReciclaje();
        FrameListaPuntosDeReciclaje refp = new FrameListaPuntosDeReciclaje();
        Material m1 = new Material("Papel y cartón",
                " Incluye periódicos, revistas, cajas "
                        + "de cartón, papel de oficina, etc.");
        tipo.add(m1);
        
        Material m2 = new Material("Plástico",
                " Los envases de plástico, botellas, "
                        + "recipientes, y otros artículos de plástico");
        tipo.add(m2);
        
        Material m3 = new Material("Vidrio",
                " Botellas de vidrio, tarros y otros "
                        + "envases de vidrio son comúnmente reciclables.");
        tipo.add(m3);
    
        Material m4 = new Material("Residuos orgánicos",
                " Restos de alimentos y"
                        + " otros materiales orgánicos pueden compostarse..");
        tipo.add(m4);
        
       
        Ubicacion ubi1 = new Ubicacion("Lima", 
                "San Juan de Lurigancho", "Estación San Carlos");
        Ubicacion ubi2 = new Ubicacion("Lima", 
                "San Juan de Lurigancho", 
                "Frente del Parque Mercado 10");
        Ubicacion ubi3 = new Ubicacion("Lima", 
                "San Juan de Lurigancho", "Estacion los postes");
        Ubicacion ubi4 = new Ubicacion("Lima", 
                "San Juan de Lurigancho",
                "Av. Los Ciruelos 526 - 540, San Juan de Lurigancho 15434");
        Ubicacion ubi5 = new Ubicacion("Lima", 
                "San Juan de Lurigancho", "Estacion San Carlos");
        Ubicacion ubi6 = new Ubicacion("Lima", 
                "San Juan de Lurigancho", "Villa Huanta");
       
        
        PuntoReciclaje punto1 = new PuntoReciclaje("Punto San Carlos"
                , ubi1, "Todo el día");
        punto1.agregarMaterial(m1);
        punto1.agregarMaterial(m2);
        puntos.add(punto1);
        
        PuntoReciclaje punto2 = new PuntoReciclaje("Punto Recicladora"
                + " frente al Parque", ubi2, "7AM - 6PM");
        punto2.agregarMaterial(m3);
        punto2.agregarMaterial(m4);
        puntos.add(punto2);
        
        
        PuntoReciclaje punto3 = new PuntoReciclaje("Recicladora Belmon",
                ubi3, "Todo el día");
	punto3.agregarMaterial(m1);
        punto3.agregarMaterial(m2);
	punto3.agregarMaterial(m3);
        puntos.add(punto3);
        
        PuntoReciclaje punto4 = new PuntoReciclaje("SAR AMBIENTAL S.A.",
                ubi4, "Todo el día");
	punto4.agregarMaterial(m1);
        punto4.agregarMaterial(m2);
	punto4.agregarMaterial(m3);
        puntos.add(punto4);
        
        PuntoReciclaje punto5 = new PuntoReciclaje("Wimecar S.A.C",
                ubi5, "Todo el día");
	punto5.agregarMaterial(m1);
        punto5.agregarMaterial(m2);
	punto5.agregarMaterial(m3);
        puntos.add(punto5);

        PuntoReciclaje punto6 = new PuntoReciclaje("Chat"
                + "arreria y recicladora Ems cotrina sac",
                ubi6, "Todo el día");
	punto6.agregarMaterial(m1);
        punto6.agregarMaterial(m2);
	punto6.agregarMaterial(m3);
        puntos.add(punto6);
        
        refp.gen(ref.TEXTO(punto1));
        refp.gen(ref.TEXTO(punto2));
        refp.gen(ref.TEXTO(punto3));
        refp.gen(ref.TEXTO(punto4));
        refp.gen(ref.TEXTO(punto5));
        refp.gen(ref.TEXTO(punto6));
      
    }
    
    
    
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FramePuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FramePuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FramePuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FramePuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FramePuntosDeReciclaje(new FrameGuiaApp()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Volver;
    private javax.swing.JButton btn_Fav;
    private javax.swing.JButton btn_VerList;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

    void setLocale(FramePuntosDeReciclaje padre) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
