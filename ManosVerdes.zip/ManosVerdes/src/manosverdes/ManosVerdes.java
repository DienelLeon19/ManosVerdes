    package manosverdes;

public class ManosVerdes {
    public static void main(String[] args) 
    {
        FrameLogin Ref = new FrameLogin();
        Ref.setLocationRelativeTo(Ref);
        Ref.setVisible(true);     
        
   
    }
}
