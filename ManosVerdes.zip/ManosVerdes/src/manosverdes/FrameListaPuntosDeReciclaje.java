    package manosverdes;

import Entidades.*;
import java.util.List;
import javax.swing.DefaultListModel;

public class FrameListaPuntosDeReciclaje extends javax.swing.JFrame {
       
    FramePuntosDeReciclaje padre;
    DefaultListModel<String>  model = new DefaultListModel();
    
    

    public FrameListaPuntosDeReciclaje( ) 
    {
        initComponents();

    }

    public FrameListaPuntosDeReciclaje(FramePuntosDeReciclaje padre, List<PuntoReciclaje> puntos) 
    {
        initComponents();
        this.padre=padre;
        llenarModelo(puntos);
        lst_Puntos.setModel(model);
    }

    public void llenarModelo(List<PuntoReciclaje> puntos) 
    {
        for (PuntoReciclaje punto : puntos) {
            gen(punto.TEXTO(punto));
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lst_Puntos = new javax.swing.JList<>();
        jLabel3 = new javax.swing.JLabel();
        txt_Buscar = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Volver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lst_Puntos.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jScrollPane2.setViewportView(lst_Puntos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 900, 340));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesP/lblPuntosReciclaje.png"))); // NOI18N
        jLabel3.setToolTipText("");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, -1, -1));

        txt_Buscar.setFont(new java.awt.Font("Arial", 2, 18)); // NOI18N
        txt_Buscar.setBorder(null);
        txt_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_BuscarActionPerformed(evt);
            }
        });
        jPanel1.add(txt_Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 430, 40));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesP/txtBuscar.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, -1, -1));

        Volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesD/v1.png"))); // NOI18N
        Volver.setBorder(null);
        Volver.setContentAreaFilled(false);
        Volver.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesD/v2.png"))); // NOI18N
        Volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VolverActionPerformed(evt);
            }
        });
        jPanel1.add(Volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 640, 150, 70));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FramesI/fondoPrincipal.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    public void gen(String txt)
    {
        model.addElement(txt);
    }
    
    
    
    
    private void txt_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_BuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_BuscarActionPerformed

    private void VolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VolverActionPerformed
        this.setVisible(false);
        this.padre.setLocationRelativeTo(padre);
        this.padre.setVisible(true);
    }//GEN-LAST:event_VolverActionPerformed


    
    
    
    
    
    
    
    
    
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameListaPuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameListaPuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameListaPuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameListaPuntosDeReciclaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameListaPuntosDeReciclaje().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Volver;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> lst_Puntos;
    private javax.swing.JTextField txt_Buscar;
    // End of variables declaration//GEN-END:variables
}
