    package Entidades;

public interface Persona
{
    public void ObtenerUser();
}
