    package Entidades;


public interface Admin 
{
    
    
    
    public void ObtenerUser();
    
    
}
